$(document).ready(function() {
    $('#sizePicker').submit(function makeGrid(g) {
        $('table tr').remove();
        //this loop is for making grid(row and column);
        for (var i = 1; i <= $('#input_height').val(); i++) {
            $('table').append('<tr></tr>');
            for (var j = 1; j <= $('#input_width').val(); j++) {
                $('tr:last').append('<td></td>');
                $('td').attr("class", 'cells');
            }
        }
        g.preventDefault();
        //color will be filled in the boxes;
        $('.cells').click(function(event) {
            var paint = $('#colorPicker').val();

            $(event.target).css('background-color', paint);
        });
    });
});